package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.classes.User;

public class ProfileActivity extends AppCompatActivity{

    TextView username,useremail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        username=findViewById(R.id.username);
        useremail=findViewById(R.id.useremail);

        Intent intent=getIntent();
        User currentUser = (User) intent.getSerializableExtra("currentUser");
        String uname = currentUser.getName();
        String uemail = currentUser.getEmail();

        username.setText(uname);
        useremail.setText(uemail);

    }

}
